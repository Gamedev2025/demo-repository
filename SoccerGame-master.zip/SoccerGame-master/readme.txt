This game is a simple 2D-soccer game. 
The objective is to score as many points as possible in the opponents goal.

Controls:

Keyboard:

 -Player 1:
   Left:  A
   Up:    W / Space
   Right: D

 -Player 2:
   Arrowkeys

Xbox controller:

Left and right movement: Left stick
Up:                      A button

The controls can also be found inside the game.

-Opponent and time format can be changed in the settings menu.