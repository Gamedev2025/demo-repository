# MiniSoccer2D
                                                             MINI SOCCER
                          affiliation: Faculty of Automatic Control and Computer Engineering, Iasi
                                                    email: moisii.marin@gmail.com
                                                      academic year: 2018 – 2019

>>Gameplay: A mini soccer game brings face to face two talented players. Each of them must defend his gate and score as many goals as possible in the opponent’s gate, until the time is over. After the time has ended, the player who has scored more goals is the winner. If during the match, both players have scored the same number of goals, then will start golden goal mode – there is no time limit and who scored first wins.

>>Programming language: C++
